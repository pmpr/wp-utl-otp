<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6819d5fd9ab99             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\OTP; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
