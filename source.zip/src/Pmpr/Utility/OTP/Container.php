<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fcb9b682af             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\OTP; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
