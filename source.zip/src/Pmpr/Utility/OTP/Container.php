<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6816a4d902dde             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\OTP; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
