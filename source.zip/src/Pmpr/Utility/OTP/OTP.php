<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169d9eb60f0             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\OTP; use Pmpr\Common\Foundation\Container\UtilityInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; class OTP extends UtilityInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __('OTP Generator', PR__UTL__OTP); }, Constants::wuowaiyouwecckaw => false, Constants::sguyaymiiiiewame => Setting::class]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); } }
