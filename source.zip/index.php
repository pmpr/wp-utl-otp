<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68174a0d0e063             |
    |_______________________________________|
*/
 use Pmpr\Utility\OTP\Model\Request; use Pmpr\Utility\OTP\OTP; OTP::symcgieuakksimmu(); if (!function_exists('pr_utility_otp_get_request')) { function pr_utility_otp_get_request() : Request { return Request::symcgieuakksimmu(); } }
