<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6816a4d902dde             |
    |_______________________________________|
*/
 use Pmpr\Utility\OTP\Model\Request; use Pmpr\Utility\OTP\OTP; OTP::symcgieuakksimmu(); if (!function_exists('pr_utility_otp_get_request')) { function pr_utility_otp_get_request() : Request { return Request::symcgieuakksimmu(); } }
